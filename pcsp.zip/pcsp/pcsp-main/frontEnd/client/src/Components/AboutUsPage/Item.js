import styled from "styled-components";

export default styled.div`
  justify-content: center;
  align-items: center;
  
  height: 325px;
  width: 100%;
  width: 400px;
  background-color: #E4635D;
  color: #fff;
  margin: 0 15px;
  font-size: 4em;

`;