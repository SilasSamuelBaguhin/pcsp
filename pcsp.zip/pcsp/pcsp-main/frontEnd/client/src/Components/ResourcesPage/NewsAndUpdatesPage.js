import React from 'react';
import { Container } from '@material-ui/core'

import './NewsAndUpdatesPage.css'

const NewsAndUpdatesPage = () => {

    return (
        <div >
            <Container classname="Infographics">
                <h1>NEWS AND UPDATES</h1>
                <h1>NEWS AND UPDATES</h1>
                <h1>NEWS AND UPDATES</h1>
                <h1>NEWS AND UPDATES</h1>
                <h1>NEWS AND UPDATES</h1>
                <h1>NEWS AND UPDATES</h1>
                <h1>NEWS AND UPDATES</h1>
                <h1>NEWS AND UPDATES</h1>
                <h1>NEWS AND UPDATES</h1>
                <h1>NEWS AND UPDATES</h1>
                <h1>NEWS AND UPDATES</h1>
                <h1>NEWS AND UPDATES</h1>
                <h1>NEWS AND UPDATES</h1>
            </Container>
        </div>
    );

}

export default NewsAndUpdatesPage;



